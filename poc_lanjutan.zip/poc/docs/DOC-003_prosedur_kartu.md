doc_id: DOC-003
judul: Prosedur Layanan Kartu Debit
versi: 1.2
berlaku: 1 Februari 2026
jenis: resmi
catatan: DOKUMEN FIKTIF untuk keperluan PoC PT Bank Nusantara Mandiri. Seluruh isi fiktif.

## Pasal 1. Kartu Hilang atau Dicuri
Nasabah wajib segera memblokir kartu melalui salah satu saluran berikut: aplikasi mobile banking (menu Kartu, lalu Blokir Kartu, tersedia setiap saat), contact center pada jam kerja Senin sampai Jumat pukul 08.00 sampai 17.00 WIB, atau kantor cabang pada jam kerja.

## Pasal 2. Penggantian Kartu
Penggantian kartu diajukan di kantor cabang dengan membawa KTP. Biaya penggantian mengikuti DOC-001 Pasal 3, yaitu Rp 25.000. Kartu pengganti dapat diambil dalam 5 hari kerja setelah pengajuan.

## Pasal 3. PIN
PIN kartu debit terdiri dari 6 digit. Kartu terblokir otomatis setelah 3 kali salah memasukkan PIN. Pembukaan blokir dan pengaturan ulang PIN dilakukan di kantor cabang dengan membawa KTP dan kartu.

## Pasal 4. Aktivasi Kartu Baru
Kartu baru diaktivasi melalui aplikasi mobile banking atau ATM paling lambat 30 hari sejak kartu diterima, disertai penggantian PIN awal.

## Pasal 5. Batas Transaksi Harian
Batas penarikan tunai di ATM adalah Rp 10.000.000 per hari. Batas transaksi belanja dengan kartu debit adalah Rp 25.000.000 per hari.

## Pasal 6. Transaksi yang Tidak Dikenali
Laporan transaksi yang tidak dikenali nasabah, dugaan penipuan, dan sengketa transaksi ditangani oleh Unit Penanganan Sengketa melalui petugas. Asisten virtual tidak memproses laporan tersebut dan mengalihkannya kepada petugas.
