doc_id: DOC-004
judul: FAQ Layanan Nasabah (Statis)
versi: 3.0
berlaku: 12 Juni 2025
jenis: faq
catatan: DOKUMEN FIKTIF untuk keperluan PoC PT Bank Nusantara Mandiri. FAQ tidak diperbarui mengikuti perubahan ketentuan terbaru. Bila bertentangan dengan dokumen resmi, dokumen resmi yang berlaku.

## FAQ 1. Biaya Administrasi Tabungan
Berapa biaya administrasi bulanan Tabungan Reguler? Biaya administrasi bulanan Tabungan Reguler adalah Rp 10.000 per bulan.

## FAQ 2. Cara Cek Saldo
Bagaimana cara mengecek saldo? Saldo dapat dicek melalui aplikasi mobile banking atau mesin ATM.

## FAQ 3. Jam Layanan Contact Center
Kapan contact center melayani nasabah? Contact center melayani pada hari Senin sampai Jumat pukul 08.00 sampai 17.00 WIB.

## FAQ 4. Transfer ke Bank Lain
Apakah nasabah dapat mentransfer ke bank lain? Dapat. Transfer ke bank lain dilakukan melalui aplikasi mobile banking dan dikenai biaya sesuai ketentuan yang berlaku.

## FAQ 5. Kartu Terblokir
Mengapa kartu saya terblokir? Kartu terblokir otomatis setelah beberapa kali salah memasukkan PIN. Silakan datang ke kantor cabang terdekat.
