doc_id: DOC-001
judul: Ketentuan Produk dan Tarif Tabungan dan Kartu Debit
versi: 2.1
berlaku: 1 Januari 2026
jenis: resmi
catatan: DOKUMEN FIKTIF untuk keperluan PoC PT Bank Nusantara Mandiri. Seluruh isi, termasuk tarif, fiktif.

## Pasal 1. Tabungan Reguler: Setoran Awal dan Saldo Minimum
Setoran awal pembukaan Tabungan Reguler adalah Rp 100.000. Saldo minimum yang harus mengendap pada rekening adalah Rp 50.000. Pembukaan rekening dilakukan di kantor cabang dengan membawa KTP dan NPWP bila ada.

## Pasal 2. Biaya Administrasi Bulanan
Biaya administrasi bulanan Tabungan Reguler adalah Rp 12.500 per bulan, berlaku sejak versi 2.1 (sebelumnya Rp 10.000). Biaya administrasi dibebaskan bagi rekening dengan saldo rata-rata bulanan sebesar Rp 5.000.000 atau lebih.

## Pasal 3. Kartu Debit
Biaya penerbitan kartu debit baru adalah Rp 25.000. Biaya tahunan kartu debit adalah Rp 36.000. Biaya penggantian kartu debit yang hilang atau rusak adalah Rp 25.000 per kartu.

## Pasal 4. Transfer
Transfer antar rekening sesama Bank Nusantara Mandiri tidak dikenai biaya. Transfer ke bank lain melalui BI-FAST dikenai biaya Rp 2.500 per transaksi.

## Pasal 5. Transaksi di ATM Bank Lain
Penarikan tunai di ATM bank lain dikenai biaya Rp 6.500 per transaksi. Cek saldo di ATM bank lain dikenai biaya Rp 2.500 per transaksi.

## Pasal 6. Penutupan Rekening
Penutupan rekening yang dilakukan dalam waktu 90 hari sejak tanggal pembukaan dikenai biaya Rp 50.000. Penutupan rekening setelah 90 hari tidak dikenai biaya. Rekening dinyatakan tidak aktif (dormant) bila tidak ada transaksi selama 12 bulan berturut-turut.
