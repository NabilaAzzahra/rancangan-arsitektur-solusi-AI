doc_id: DOC-002
judul: Syarat dan Ketentuan Kredit (KTA, KPR, dan Kartu Kredit)
versi: 1.4
berlaku: 1 Maret 2026
jenis: resmi
catatan: DOKUMEN FIKTIF untuk keperluan PoC PT Bank Nusantara Mandiri. Seluruh isi, termasuk tarif, fiktif.

## Pasal 1. Kredit Tanpa Agunan (KTA): Persyaratan
Pemohon KTA berusia 21 sampai 55 tahun pada saat pengajuan dan berusia paling tinggi 60 tahun pada saat kredit lunas. Penghasilan minimal Rp 5.000.000 per bulan dengan masa kerja minimal 1 tahun. Plafon KTA adalah Rp 10.000.000 sampai Rp 200.000.000 dengan tenor 12 sampai 60 bulan.

## Pasal 2. KTA: Biaya dan Denda
Biaya provisi KTA adalah 1% dari plafon kredit. Denda keterlambatan pembayaran angsuran KTA adalah 0,1% per hari dari angsuran yang tertunggak.

## Pasal 3. Kredit Pemilikan Rumah (KPR): Persyaratan
Uang muka KPR minimal 15% dari harga properti. Tenor KPR paling lama 20 tahun. Dokumen yang diperlukan: KTP, NPWP, slip gaji 3 bulan terakhir, rekening koran 3 bulan terakhir, dan sertifikat properti (SHM atau HGB).

## Pasal 4. KPR: Biaya
Biaya provisi KPR adalah 1% dari plafon kredit. Pelunasan dipercepat pada tahun pertama dikenai penalti 2% dari sisa pokok kredit.

## Pasal 5. Kartu Kredit
Pemohon kartu kredit Nusantara Platinum harus berpenghasilan minimal Rp 8.000.000 per bulan. Iuran tahunan kartu kredit Nusantara Platinum adalah Rp 500.000. Pembayaran minimum adalah 10% dari total tagihan. Denda keterlambatan adalah 1% dari total tagihan dengan minimal Rp 75.000.

## Pasal 6. Proses Persetujuan
Keputusan atas permohonan kredit disampaikan paling lama 14 hari kerja setelah dokumen dinyatakan lengkap. Persetujuan kredit merupakan keputusan petugas kredit dan tidak diberikan oleh asisten virtual.
